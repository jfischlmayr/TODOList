import { Component, OnInit } from '@angular/core';
import { TODO } from './todo';
import { TODOService } from './todo.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'todo-frontend';
  searchQuery = '';
  actCountry = '';
  
  currentTodo: TODO = new TODO;

  ts: TODOService;

  constructor(todoService: TODOService) {
    this.ts = todoService;
  } 

  // Lifecycle hook
  ngOnInit(): void {
    this.ts.getTODOs();
  }

  matches = (todo: TODO) => todo
    .name
    .toLowerCase()
    .startsWith(this
      .searchQuery
      .toLowerCase())

  addTODO = () => {
    let id = this.calculateNewId();

    this.currentTodo.id = id;

    this.ts.post(this.currentTodo);
    this.clearInputs();
  }

  edit = (todo : TODO) => {
    this.ts.updateTODO(todo);
  }

  removeTODO = (todo: TODO) => {
    this.ts.deleteTODO(todo);
  }

  sortByName = () => this.ts.todos.sort((a, b) => a.name.localeCompare(b.name));
  sortByDueDate = () => this.ts.todos.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  sortByPerson = () => this.ts.todos.sort((a, b) => a.person.localeCompare(b.person));
  sortByStatus = () => this.ts.todos.sort((a, b) => a.status.localeCompare(b.status));

  private calculateNewId() {
    const highestId = Math.max.apply(null, this.ts.todos.map(t => t.id))
    return highestId + 1;
  }

  public applyEdit() {
    this.ts.updateTODO(this.currentTodo);
    this.currentTodo = new TODO;
  }

  clearInputs() {
    this.currentTodo.name = "";
    this.currentTodo.dueDate = "";
    this.currentTodo.person = "";
    this.currentTodo.status = "";
}

  updateTodo = (todo: TODO) => {
    this.currentTodo = todo;
  }
}
