import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { TODODetailComponent } from './todo-detail/todo-detail.component';
import { TODOService } from './todo.service';

@NgModule({
  declarations: [
    AppComponent,
    TODODetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [TODOService],
  bootstrap: [AppComponent]
})
export class AppModule { }
