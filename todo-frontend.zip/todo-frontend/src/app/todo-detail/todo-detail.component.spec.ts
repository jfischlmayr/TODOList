import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TODODetailComponent } from './todo-detail.component';

describe('PersonDetailComponent', () => {
  let component: TODODetailComponent;
  let fixture: ComponentFixture<TODODetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TODODetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TODODetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
