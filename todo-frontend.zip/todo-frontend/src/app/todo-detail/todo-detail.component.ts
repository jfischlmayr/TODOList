import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TODO } from '../todo';

@Component({
  selector: 'app-todo-detail',
  templateUrl: './todo-detail.component.html',
  styleUrls: ['./todo-detail.component.css']
})
export class TODODetailComponent implements OnInit {
  
  @Input() item = new TODO()
  @Input() color = 'white'
  @Output() deleteMe = new EventEmitter<TODO>()
  @Output() editMe = new EventEmitter<TODO>()
  editing = false

  constructor() { }

  ngOnInit(): void {
  }

  public onRemove() {
    this.deleteMe.emit()
  }

  public onEdit() {
    this.editMe.emit()
  }
}
