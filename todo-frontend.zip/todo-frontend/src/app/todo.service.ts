import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TODO } from './todo';

@Injectable({
  providedIn: 'root'
})
export class TODOService {

  private http: HttpClient

  public todos!: TODO[];

  constructor(http: HttpClient) {
    this.http = http
  }

  public post(toAdd: TODO) {
    this.http.post('http://localhost:8080/todo/create', toAdd).subscribe(() => this.getTODOs())
  }

  public getTODOs() {
    this.http.get<TODO[]>('http://localhost:8080/todo/findAll')
        .subscribe(data => this.todos = data)
  }

  public deleteTODO(todo:TODO) {
    this.http.delete('http://localhost:8080/todo/delete/' + todo.id)
    .subscribe()
    this.http.get<TODO[]>('http://localhost:8080/todo/findAll')
        .subscribe(data => this.todos = data)
  }

  public updateTODO(toUpdate:TODO) {
    this.http.put('http://localhost:8080/todo/update', toUpdate).subscribe()
  }
}
