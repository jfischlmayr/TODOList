import { TODO } from './todo';

describe('TODO', () => {
  it('should create an instance', () => {
    expect(new TODO()).toBeTruthy();
  });
});
