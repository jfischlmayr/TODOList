export class TODO {
    id!: number
    name!: string
    dueDate!: string
    person!: string
    status!: string
}
